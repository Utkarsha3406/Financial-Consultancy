# Log_reg


website page https://priyanshu581.github.io/PROJECT-1/main.html
